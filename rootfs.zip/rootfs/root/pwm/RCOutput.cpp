/// -*- tab-width: 4; Mode: C++; c-basic-offset: 4; indent-tabs-mode: nil -*-
/*
 * Copyright (C) 2015  Intel Corporation. All rights reserved.
 *
 * This file is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This file is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "RCOutput.h"
#include "Util.h"

//namespace Linux {

RCOutput::RCOutput(uint8_t chip, uint8_t channel)
    : _chip(chip)
    , _channel(channel)
    , _pwm_channel(new PWM_Sysfs(chip, channel))
{
}

RCOutput::~RCOutput()
{
    delete _pwm_channel;
}

#if 1
void RCOutput::init()
{
        if (!_pwm_channel) {
            panic("RCOutput_PWM: Unable to setup PWM pin.");
        }
if (_pwm_channel->is_enabled())
        _pwm_channel->enable(false);

        /* Set the initial frequency */
        _pwm_channel->set_freq(50);
        _pwm_channel->set_duty_cycle(0);
        _pwm_channel->set_polarity(PWM_Sysfs::Polarity::NORMAL);
}
#endif

void RCOutput::set_period(uint32_t ns)
{
            _pwm_channel->set_period(ns);
}

uint32_t RCOutput::get_period()
{
    return _pwm_channel->get_period();
}

void RCOutput::set_freq(uint32_t freq_hz)
{
            _pwm_channel->set_freq(freq_hz);
}

uint32_t RCOutput::get_freq()
{
    return _pwm_channel->get_freq();
}

void RCOutput::enable()
{
    _pwm_channel->enable(true);
}

void RCOutput::disable()
{
    _pwm_channel->enable(false);
}

void RCOutput::write(uint32_t ns)
{
    _pwm_channel->set_duty_cycle(ns);
}

void RCOutput::write_percent(float percent)
{
    uint32_t ns = _pwm_channel->get_period();
    ns = (uint32_t) (ns * percent);
    _pwm_channel->set_duty_cycle(ns);
}

uint32_t RCOutput::read()
{
    return _pwm_channel->get_duty_cycle();
}

//}

