#include "PWM_Sysfs.h"

class RCOutput {
public:
    RCOutput(uint8_t chip, uint8_t channel);
    ~RCOutput();

    void init();
    void set_period(uint32_t ns);
    uint32_t get_period();
    void set_freq(uint32_t freq_hz);
    uint32_t get_freq();
    void enable();
    void disable();
    void write(uint32_t period_us);
    void write_percent(float percent);
    uint32_t read();

private:
    const uint8_t _chip;
    const uint8_t _channel;
    PWM_Sysfs *_pwm_channel;
};

