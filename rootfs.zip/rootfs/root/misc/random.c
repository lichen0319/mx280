#include <sys/file.h>
#include <stdio.h>

int main(void)
{
	char seed[32];
	int i;

	int fd = open("/dev/urandom", O_RDONLY);
//	int fd = open("/dev/random", O_RDONLY);  /* maybe block very long time */

	read(fd, seed, sizeof(seed));

	for (i = 0; i < sizeof(seed); i++)
		printf("0x%02x ", (unsigned char) seed[i]);
	printf("\n");

	return 0;
}
