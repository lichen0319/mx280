#include "RCOutput.h"

#if 1
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#else
#include <iostream>

#endif


int main(void)
{
	int i;

	RCOutput rc(0,3);

	rc.set_freq(1000);
	rc.enable();

do {
	for (i = 1; i < 1000; i++) {
		rc.write_percent(i/2000.0);
		usleep(2000);
	}

	for (; i > 0; i--) {
		rc.write_percent(i/2000.0);
		usleep(2000);
	}

	rc.write(0);
	usleep(150000);

} while (1);

	rc.write(0);
	rc.disable();

	return 0;
}
